<!DOCTYPE html>
<html lang="en"><head>
	<title> Real-estate </title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">  
	<script type="text/javascript" src="<?php echo base_url() ?>vendor/bootstrap.js"></script>
	<!-- <script type="text/javascript" src="isotope.pkgd.min.js"></script> -->
	<link rel="stylesheet" href="<?php echo base_url() ?>vendor/bootstrap.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>vendor/font-awesome.css">
 	<link rel="stylesheet" href="<?php echo base_url() ?>1.css">
 	<!-- <link href="https://fonts.googleapis.com/css?family=Kaushan+Script" rel="stylesheet"> -->
	<link href="https://fonts.googleapis.com/css?family=Dancing+Script:400,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Lobster" rel="stylesheet">
	<link rel="stylesheet" href="animate.css">
	<script src="<?php echo base_url() ?>jquery.easing.1.3.js"></script>
	<link  href="<?php echo base_url() ?>fancybox-master/dist/jquery.fancybox.min.css" rel="stylesheet">
 	<script src="<?php echo base_url() ?>fancybox-master/dist/jquery.fancybox.min.js"></script>
 	<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/1.20.4/TweenMax.min.js"></script>
</head>
<body data-spy="scroll" data-target=".navbar" data-offset="70">
	
	<div class="banner">
		<nav class="navbar navbar-fixed-top navbar-light bg-faded dieuchinh ">
          <button class="navbar-toggler hidden-lg-up" type="button" data-toggle="collapse" data-target="#exCollapsingNavbar2">
          </button>
          <div class="collapse navbar-toggleable-lg" id="exCollapsingNavbar2">
            <a class="navbar-brand hidden-sm-down" href="#">GI co. ltd</a>
            <ul class="nav navbar-nav">
              <li class="nav-item active">
                <a class="nav-link home" href="#so1">Home <span class="sr-only">(current)</span></a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#so2">Landscape</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#so3">Villa</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#so4">Apartment</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#so5">Price</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#so6">About us</a>
              </li>
            </ul>
          </div>
        </nav>
        <div id="so1" class="slide">
			<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
				<ol class="carousel-indicators">
					<li data-target="#carousel-example-generic" data-slide-to="0" class="active"></li>
					<li data-target="#carousel-example-generic" data-slide-to="0"></li>
					<li data-target="#carousel-example-generic" data-slide-to="0"></li>
				</ol>
				<div class="carousel-inner" role="listbox">
                <?php foreach ($mangdl as $value): ?>
                    <div class="carousel-item"> <!-- bình thường còn có class active ở slide đầu tiên, nhưung vì dùng foreach nên phải bỏ, ta thêm vào bằng Js -->
                        <img src="<?= $value['slide_image'] ?>" alt="First slide">
                    </div>
                <?php endforeach ?>
					
					<!-- <div class="carousel-item">
						<img src="images/house1.jpg" alt="2th slide">
					</div>
					<div class="carousel-item">
						<img src="images/house2.jpg" alt="3th slide">
					</div> -->
				</div>
				<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
					<span class="icon-prev" aria-hidden="true"></span>
					<span class="sr-only">Previous</span>
				</a>
				<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
					<span class="icon-next" aria-hidden="true"></span>
					<span class="sr-only">Next</span>
				</a>
			</div>
        </div>		
    </div> <!-- het banner -->
        <div id="so2" class="landscape ">
        	<div class="container">
        		<div class="row">
        			<div class="col-sm-8 push-sm-2">
        				<div class="lsctext">
        				Nằm tọa lạc tại cuối đường A, thuộc quận Hà Đông-Hà Nội, với vị trí đắc địa, khu đô thị Z có cảnh quan thoáng đãng, là không gian sống thích hợp cho cá nhân hay hộ gia đình ở mọi lứa tuổi: 
        				</div>
        			</div>
        		</div>
        		<div class="row">
        			<div class="col-sm-3">

                       <?php foreach ($mangdl1 as $key => $value): ?>
                            <?php if( $key <=2 && $key >=0) { ?>
                             <a href="<?= $value['landscape_image'] ?>" data-fancybox="group"><img src="<?= $value['landscape_image'] ?>" alt="" class="anh"></a>
                             <?php } ?>
                       <?php endforeach ?>
                          
                    </div>
        			<div class="col-sm-3 hidden-sm-down">
        			    <?php foreach ($mangdl1 as $key => $value): ?>
                            <?php if( $key <=5 && $key >=3) { ?>
                             <a href="<?= $value['landscape_image'] ?>" data-fancybox="group"><img src="<?= $value['landscape_image'] ?>" alt="" class="anh"></a>
                             <?php } ?>
                  <?php endforeach ?>
        			</div>
        			<div class="col-sm-3 hidden-sm-down">
                		<?php foreach ($mangdl1 as $key => $value): ?>
                            <?php if( $key <=8 && $key >=6) { ?>
                             <a href="<?= $value['landscape_image'] ?>" data-fancybox="group"><img src="<?= $value['landscape_image'] ?>" alt="" class="anh"></a>
                             <?php } ?>
                    <?php endforeach ?>
        			</div>
        			<div class="col-sm-3">
                  <?php foreach ($mangdl1 as $key => $value): ?>
        				      <?php if( $key <=11 && $key >=9) { ?>
                             <a href="<?= $value['landscape_image'] ?>" data-fancybox="group"><img src="<?= $value['landscape_image'] ?>" alt="" class="anh"></a>
                             <?php } ?>
                  <?php endforeach ?>
        			</div>
        		</div>
        	</div>
        </div>
        <div id="so3" class="villa">
        	<div class="container">
        	<div class="row">
        			<div class="col-sm-6">
        				<a href="images/house5.jpg" data-fancybox="group2"><img src="images/house5.jpg" alt="" class="anh1villa"></a>
        				<div class="textvilla"> Turkey picanha strip steak frankfurter </div>
        				<div class="ke"></div>
        				<div class="text2villa"> T-bone ground round jowl tenderloin andouille chicken filet mignon turducken shankle. Drumstick picanha chicken pork pork belly pig sirloin kielbasa bacon shoulder buffalo short loin doner chuck turkey. Strip steak t-bone picanha porchetta. Pancetta jowl ground round, fatback tenderloin swine burgdoggen andouille t-bone corned beef chuck turducken sirloin brisket.</div>
        			
        			</div>
        			<div class="col-sm-6">
        				<a href="images/house9.jpg" data-fancybox="group2"><img src="images/house9.jpg" alt="" class="anh2villa"></a>
       	        		<div class="textvilla"> Turkey picanha strip steak frankfurter </div>
        				<div class="ke"></div>
        				<div class="text2villa"> T-bone ground round jowl tenderloin andouille chicken filet mignon turducken shankle. Drumstick picanha chicken pork pork belly pig sirloin kielbasa bacon shoulder buffalo short loin doner chuck turkey. Strip steak t-bone picanha porchetta. Pancetta jowl ground round, fatback tenderloin swine burgdoggen andouille t-bone corned beef chuck turducken sirloin brisket.</div>
        			</div>
        		</div>
        	</div>
        </div>
        <div id="so4" class="apartment">
        	<div class="container">
        		<div class="row">
        			<div class="col-sm-4 ap">
        				<a href="images/pic6.jpeg" data-fancybox="group3"><img src="images/pic6.jpeg" alt="" class="anhap"></a>
        				<div class="text1ap">T-bone ground round jowl</div>
        				<div class="ke"></div>
        				<div class="text2ap">Drumstick picanha chicken pork pork belly pig sirloin kielbasa bacon shoulder buffalo short loin doner chuck turkey. Strip steak t-bone picanha porchetta. Pancetta jowl ground round</div>
        			</div>
        			<div class="col-sm-4 ap">
        				<a href="images/pic2.jpeg" data-fancybox="group3"><img src="images/pic2.jpeg" alt="" class="anhap"></a>
        				<div class="text1ap">T-bone ground round jowl</div>
        				<div class="ke"></div>
        				<div class="text2ap">Drumstick picanha chicken pork pork belly pig sirloin kielbasa bacon shoulder buffalo short loin doner chuck turkey. Strip steak t-bone picanha porchetta. Pancetta jowl ground round</div>
        			</div>
        			<div class="col-sm-4 ap">
        				<a href="images/pic14.jpeg" data-fancybox="group3"><img src="images/pic14.jpeg" alt="" class="anhap"></a>
        				<div class="text1ap">T-bone ground round jowl</div>
        				<div class="ke"></div>
        				<div class="text2ap">Drumstick picanha chicken pork pork belly pig sirloin kielbasa bacon shoulder buffalo short loin doner chuck turkey. Strip steak t-bone picanha porchetta. Pancetta jowl ground round</div>
        			</div>
        		</div>
        	</div>
        </div> <!-- het apartment -->
        <div id="so5" class="price">
        	<div class="container">
        		<div class="row">
        			<div class="col-sm-4">
        				<div class="text1pr">Chung cư</div>
        				<div class="ke"></div>
						<div class="text2pr">
						<p>
							- 70m2:  20-22tr/m2. <br />
							- 86m2:  19-21tr/m2. <br />
							- 112m2: 18-21tr/m2. <br />
							- 154m2 (penHouse): 25tr/m2. 
						</p>
							
						</div>
						<div class="text1pr">Biệt thự</div>
						<div class="ke"></div>
						<div class="text2pr">
						<p>
							- 150m2: 40-44tr/m2. <br />
							- 200m2: 40-44tr/m2. <br />
							- 250m2: 38-44tr/m2/m2.
						</p>
							
						</div>
        			</div>
        			<div class="col-sm-4 hidden-sm-down">
        				<a href="images/tk1.jpg" data-fancybox="group4"><img src="images/tk1.jpg" alt="" class="anhpr1"></a>
        				<a href="images/tk2.jpg" data-fancybox="group4"><img src="images/tk2.jpg" alt="" class="anhpr2"></a>
        			</div>
        			<div class="col-sm-4 hidden-sm-down">
        				<a href="images/tk3.jpg" data-fancybox="group4"><img src="images/tk3.jpg" alt="" class="anhpr1"></a>
        				<a href="images/tk4.jpg" data-fancybox="group4"><img src="images/tk4.jpg" alt="" class="anhpr2"></a>
        			</div>
        		</div>
        	</div>
        </div> <!-- het price -->
        <div id="so6" class="aboutus">
			<div class="anhabu">
				<div class="textanhabu">GIcompany đã trúng thầu và hoàn thành nhiều dự án bất động sản, nổi lên như một công ty trẻ đầy tiềm năng tại Việt Nam</div>
			</div>
			
			<div class="container">
				<div class="row info">
					<div class="col-sm-4">Landjaeger hamburger fatback sausage bacon drumstick burgdoggen tri-tip frankfurter filet mignon alcatra pork loin ball tip chicken swine. Spare ribs alcatra tri-tip </div>
					<div class="col-sm-4"><p>Location: <br /> 160-Hoang Mai-Ha Noi-VN</p> </div>
					<div class="col-sm-4"><p>Contact: <br /> - Email: nam.duongminh99@gmail.com <br /> - Phone number: 0964765727 </p></div>
					
				</div>
			</div>
        </div>

	
		
	<script type="text/javascript" src="<?php echo base_url() ?>1.js"></script>
</body>
</html>