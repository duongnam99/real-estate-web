<nav class="navbar navbar-light bg-faded">
      <button class="navbar-toggler hidden-sm-up" type="button" data-toggle="collapse" data-target="#exCollapsingNavbar2">
       
      </button>
      <div class="collapse navbar-toggleable-xs" id="exCollapsingNavbar2">
        <a class="navbar-brand" href="#">Admin</a>
        <ul class="nav navbar-nav">
          <li class="nav-item active">
            <a class="nav-link" href="Add_slide">Add slide </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Edit_slide">Edit slide</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="Delete_slide">Delete slide</a>
             <li class="nav-item active">
            <a class="nav-link" href="<?= base_url() ?>Landscape"> add Landscape</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>Landscape/editLandscape_image">edit Landscape</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?= base_url() ?>Landscape/deleteLandscape_image">delete Landscape</a>
          </li>
          </li>
        </ul>
      </div>
   </nav>