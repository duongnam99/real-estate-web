<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" http-equiv="refresh" content="1,url=<?php echo base_url() ?>Add_slide">
	<title>thành công</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">  
	<script type="text/javascript" src="<?php echo base_url() ?>vendor/bootstrap.js"></script>
 	<script type="text/javascript" src="<?php echo base_url() ?>1.js"></script>
	<link rel="stylesheet" href="<?php echo base_url() ?>vendor/bootstrap.css">
	<link rel="stylesheet" href="<?php echo base_url() ?>vendor/font-awesome.css">
 	<link rel="stylesheet" href="<?php echo base_url() ?>1.css">
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-6 push-sm-3">
				<div class="alert alert-info">
					<strong> Thao tác thành công</strong>
				</div>
			</div>
		</div>
	</div>
</body>
</html>